{
    "version": "1.7",
    "octreeDir": "data",
    "projection": "",
    "points": 3954696,
    "boundingBox": {
        "lx": -2.348026990890503,
        "ly": -4.915281085968017,
        "lz": 0.22387676239013655,
        "ux": 6.94775128364563,
        "uy": 4.380497188568116,
        "uz": 9.51965503692627
    },
    "tightBoundingBox": {
        "lx": -2.348026990890503,
        "ly": -4.915281085968017,
        "lz": 0.22387676239013655,
        "ux": 4.051228521700883,
        "uy": 3.624218675080858,
        "uz": 9.51965503692627
    },
    "pointAttributes": [
        "POSITION_CARTESIAN",
        "COLOR_PACKED"
    ],
    "spacing": 0.08050379902124405,
    "scale": 0.001,
    "hierarchyStepSize": 5
}